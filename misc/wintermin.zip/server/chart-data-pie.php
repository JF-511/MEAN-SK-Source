<?php

$data = array(
  array(
     'label' => 'jQuery',
     'color' => '#4acab4',
     'data' => 30
  ),
  array(
     'label' => 'CSS',
     'color' => '#ffea88',
     'data' => 40
  ),
  array(
     'label' => 'LESS',
     'color' => '#ff8153',
     'data' => 90
  ),
  array(
     'label' => 'SASS',
     'color' => '#878bb6',
     'data' => 75
  ),
  array(
     'label' => 'Jade',
     'color' => '#b2d767',
     'data' => 120
  )
);

?>